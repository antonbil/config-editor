#!/bin/bash
PLUGIN_SOURCE_DIR="/home/user/Downloads/config-editor"
cd $PLUGIN_SOURCE_DIR
# --- Configuratie ---
wp-cli.phar  i18n make-mo languages/

# De taalcode (bijv. nl_NL, en_US, de_DE).
# Dit script verwacht dat je .po-bestand deze taalcode in de naam heeft.
# Voorbeeld: Als LANGUAGE_CODE="nl_NL", verwacht het een bestand genaamd "nl_NL.po".
LANGUAGE_CODE="nl_NL"

# De text domain van je plugin of thema.
# Dit wordt gebruikt om de bestandsnamen te vormen (bijv. tablepress-query-nl_NL.po).
TEXT_DOMAIN="tablepress-query"

# De map waar je .po-bestanden zich bevinden (meestal de 'languages' of 'i18n' map).
# Pas dit pad aan naar jouw projectstructuur.
PO_FILES_DIR="./languages"
# Voorbeeld voor jouw plugin-structuur (uitgaande van script in hoofdmap plugin):
# PO_FILES_DIR="./wp-content/plugins/tablepress-query/languages"
# Of als het script IN de languages map staat:
# PO_FILES_DIR="."

# --- Script Logica ---

# Controleer of gettext (en dus msgfmt) is geïnstalleerd
if ! command -v msgfmt &> /dev/null
then
    echo "Fout: msgfmt (onderdeel van gettext) is niet gevonden."
    echo "Installeer gettext om .po bestanden te compileren."
    echo "Op Debian/Ubuntu: sudo apt-get install gettext"
    echo "Op macOS (met Homebrew): brew install gettext"
    exit 1
fi

# Vorm de bestandsnamen
PO_FILENAME="${TEXT_DOMAIN}-${LANGUAGE_CODE}.po"
MO_FILENAME="${TEXT_DOMAIN}-${LANGUAGE_CODE}.mo"

FULL_PO_PATH="${PO_FILES_DIR}/${PO_FILENAME}"
FULL_MO_PATH="${PO_FILES_DIR}/${MO_FILENAME}" # MO-bestand wordt in dezelfde map geplaatst

# Controleer of het .po-bestand bestaat
if [ ! -f "$FULL_PO_PATH" ]; then
    echo "Fout: .po-bestand niet gevonden op: $FULL_PO_PATH"
    echo "Zorg ervoor dat het bestand bestaat en de LANGUAGE_CODE en TEXT_DOMAIN correct zijn ingesteld."
    exit 1
fi

echo "Compileren van $FULL_PO_PATH naar $FULL_MO_PATH..."

# Het msgfmt commando
# -o: output bestand
# --check: controleert de geldigheid van het .po-bestand (optioneel, maar goed)
# --verbose: geeft meer output (optioneel)
msgfmt -o "$FULL_MO_PATH" --check --verbose "$FULL_PO_PATH"

# Controleer de exit status van msgfmt
if [ $? -eq 0 ]; then
    echo "Succesvol $MO_FILENAME aangemaakt."
else
    echo "Fout tijdens het compileren van het .po-bestand. Controleer de output hierboven voor details."
    exit 1
fi

echo "Klaar."
